<?php
include("libraries/Variables.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title><?php echo(constant('About'))?></title>
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="FoodeCart, HTML5 Template" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!-- FavIcon Link -->
	<link rel="icon" href="assets/images/favicon.png" type="image/gif" sizes="16x16">

	<!-- Bootstrap CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

	<!-- Date Picker CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">

	<!-- Font Awesome Icon CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">

	<!-- Slick Slider CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" href="assets/css/slick-theme.css">

	<!-- Wow Animation CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css">

	<!-- Main Style CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>


<body>

	<!-- Loader Start -->
	<div class="loader-box">
		<div class="loader">
		  <span></span>
		  <span></span>
		  <span></span>
		</div>
	</div>
	<!-- Loader Start -->

	<!-- Header Start -->
	<?php
	include("components/header.php");
	?>
	<!-- Header End -->

	<!-- Banner Start -->
	<section class="inner-banner" id="main-banner" style="background-image: url('assets/images/about-banner-img.jpg');">
		<span class="inner-banner-shape" style="background-image: url('assets/images/banner-shape.png');"></span>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12">
					<div class="banner-content">
						<h1 class="h1-title">About Us</h1>
						<div class="breadcrumbs-box">
							<a href="index.html">Home</a>
							<span><i class="fa fa-angle-right breadcrumbs-arrow" aria-hidden="true"></i> About Us</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Banner End -->

	<!-- Welcome To FoodeCart Start -->
	<section class="common-sec main-welcome" id="about-us">
		<div class="element-top">
			<img src="assets/images/element1.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element2.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-6">
					<div class="about-img-box wow fadeIn">
						<div class="page-about-img-box">
							<div class="page-about-img" style="background-image: url('assets/images/page-about-img.jpg');"></div>
						</div>
						<img src="assets/images/page-about-img2.png" alt="About Image" />
					</div>
				</div>
				<div class="col-lg-6">
					<div class="welcome-content">
						<h2 class="h2-title">Welcome To Foodecart</h2>
						<p>"Welcome to Foodecart, where every craving meets its match. Dive into a world of culinary delights with our diverse menu. From savory classics to innovative creations, we cater to every palate. Join us and embark on a gastronomic journey like no other. Satisfaction guaranteed, one bite at a time."</p>

						<div class="welcome-info">
							<div class="welcome-signature">
								<img src="assets/images/welcome-signature.png" alt="Signature">
							</div>
							<h6>Chef Jhone Doe</h6>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Welcome To FoodeCart End -->

	<!-- Why Foodecart Start -->
	<section class="why-foodecart common-sec">
		<div class="element-top">
			<img src="assets/images/element3.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element4.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="why-foodecart-title text-center">
						<h2 class="h2-title gray-after-effect">Why Foodecart</h2>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="why-foodecart-box first">
						<div class="why-foodecart-img">
							<img src="assets/images/why-foodecart-img1.png" alt="Why Foodecart Image" />
						</div>
						<h3 class="h3-title">Professional Chef</h3>
						<p>Aenean ut faucibus nunc. Nam diam arcu, dignissim tristique diam quis, mattis accumsan estibulum lacinia ipsum odio, ut tincidunt urna rhoncus id. Morbi suscipit.</p>
						<div class="why-foodecart-number">
							<p>01</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="why-foodecart-box">
						<div class="why-foodecart-img">
							<img src="assets/images/why-foodecart-img2.png" alt="Why Foodecart Image" />
						</div>
						<h3 class="h3-title">Catering Services</h3>
						<p>Aenean ut faucibus nunc. Nam diam arcu, dignissim tristique diam quis, mattis accumsan estibulum lacinia ipsum odio, ut tincidunt urna rhoncus id. Morbi suscipit.</p>
						<div class="why-foodecart-number">
							<p>02</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="why-foodecart-box last">
						<div class="why-foodecart-img">
							<img src="assets/images/why-foodecart-img3.png" alt="Why Foodecart Image" />
						</div>
						<h3 class="h3-title">Qulity Food</h3>
						<p>Aenean ut faucibus nunc. Nam diam arcu, dignissim tristique diam quis, mattis accumsan estibulum lacinia ipsum odio, ut tincidunt urna rhoncus id. Morbi suscipit.</p>
						<div class="why-foodecart-number">
							<p>03</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Why Foodecart End -->

	<!-- About Counting Start -->
	<section class="main-about-counting">
		<span class="about-counting-img" style="background-image: url('assets/images/about-counting-img.jpg');"></span>
		<span class="about-counting-shape"></span>
		<div class="container">
			<div class="row" id="counter">
				<div class="col-lg-3 col-sm-6">
					<div class="about-counter-box">
						<div class="about-counting-box">
							<h2 class="about-counting" data-count="7894">0</h2><span>+</span>
						</div>
						<p>Satisfied Coustmers</p>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="about-counter-box">
						<div class="about-counting-box">
							<h2 class="about-counting" data-count="5412">0</h2><span>+</span>
						</div>
						<p>Tables We Saver</p>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="about-counter-box">
						<div class="about-counting-box">
							<h2 class="about-counting" data-count="3154">0</h2><span>+</span>
						</div>
						<p>Our Food Ratings</p>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="about-counter-box">
						<div class="about-counting-box">
							<h2 class="about-counting" data-count="15">0</h2><span>+</span>
						</div>
						<p>Years Of Experience</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- About Counting End -->

	<!-- Our Chefs Start -->
	<section class="main-chefs common-sec gray-back" id="team">
		<div class="element-top">
			<img src="assets/images/element7.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element8.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="chefs-title">
						<h2 class="h2-title">Our Chefs</h2>
					</div>
				</div>
			</div>
			<div class="chefs-info">
				<div class="row chefs-slider">
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img1.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Joella Smith</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img2.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Jordan Peter</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img3.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Zoe Drew</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img4.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Jordan Peter</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Our Chefs End -->

	<!-- Testimonial - What Our Clients Say’s Start -->
	<section class="main-testimonial common-sec white-back">
		<div class="element-top">
			<img src="assets/images/element9.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element10.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="testimonial-title">
						<h2 class="h2-title gray-after-effect">What Our Clients Say’s</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="testimonial-slider">
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img2.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img3.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img4.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Testimonial - What Our Clients Say’s End -->

	<!-- Our Blog Start -->
	
	<!-- Our Blog End -->

	<!-- Footer Start -->
	<?php
	include("components/footer.php");
	?>
	<!-- Footer End -->

	<!-- Scroll To Top Start -->
	<a href="#main-banner" class="scroll-top" id="scroll-top"><span><i class="fa fa-angle-double-up" aria-hidden="true"></i></span></a>
	<!-- Scroll To Top End -->


	<!-- Jquery JS Link -->
	<script src="assets/js/jquery.min.js"></script>

	<!-- Bootstrap JS Link -->
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Date Picker JS Link -->
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/bootstrap-datetimepicker.min.js"></script>

	<!-- Slick Slider JS Link -->
	<script src="assets/js/slick.min.js"></script>

	<!-- Wow Animation JS Link -->
	<script src="assets/js/wow.min.js"></script>	

	<!-- Custom JS Link -->
	<script src="assets/js/custom.js"></script>
	<script src="assets/js/custom-scroll-count.js"></script>

</body>

<!-- Mirrored from shivaaythemes.in/foodecart-demo/Multiple_Pages/Homepage_1/about-us.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2024 17:18:02 GMT -->
</html>