<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="assets/css/adminheader.css">
</head>
<body>

<div class="open-btn" onclick="toggleSidebar()">☰</div>

<div class="sidebar" id="sidebar">
    <div class="sidebar-heading">Admin Panel</div>
    <a href="index.php" onclick="return preventSidebarClose()">Home</a>
    <a href="whyFoodecartsection.php" onclick="return preventSidebarClose()">Why Foodecart</a>
    <a href="offers.php" onclick="return preventSidebarClose()">Offers</a>
    <a href="orderlist.php" onclick="return preventSidebarClose()">Orders</a>
    <a href="gallary.php" onclick="return preventSidebarClose()">Gallery</a>
    <a href="ourchefs.php" onclick="return preventSidebarClose()">Our chefs</a>
    <a href="reviews.php" onclick="return preventSidebarClose()">Reviews</a>
    <a href="Contact.php" onclick="return preventSidebarClose()">Contact</a>
    <a href="adminlogin.php" class="option-btn" >Login</a>
    <a href="register_admin.php" class="option-btn">Register</a>
    <a href="adminlogin.php" onclick="return confirm('Are you sure you want to logout?');"  style=" background-color:#FF4F02;
    color: white;">Logout</a>
</div>

<div class="main" id="main">
    <!-- Content of your main section goes here -->
    <!-- You can keep your existing content here -->
</div>

<script>
    function toggleSidebar() {
        var sidebar = document.getElementById("sidebar");
        var main = document.getElementById("main");
        sidebar.classList.add("open");
        main.classList.add("open");
    }

    function preventSidebarClose() {
        var sidebar = document.getElementById("sidebar");
        return sidebar.classList.contains("open");
    }
</script>

</body>
</html>
