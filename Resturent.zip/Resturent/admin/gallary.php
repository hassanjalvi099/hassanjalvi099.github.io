<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>

    <link rel="stylesheet" href="assets/css/gallary.css">

    <link rel="stylesheet" href="assets/css/foodecart.css">
    
    <style>
        /* Adjust the width of the main section */
        main {
            width: 83%; /* Set the width to 70% */
            margin-left: auto; /* Align to the right */
            margin-right: 0; /* Remove default margin */
            padding: 20px;
        }
    </style>
</head>
<body>
<?php
include("components/admin_header.php");
?>
<main>
    <section id="manage-images">
        <h2>Manage Images</h2>
        <div class="image-options">
            <label for="image-upload">Upload Image:</label>
            <input type="file" id="image-upload" accept="image/*" multiple>
            <select id="category-select">
                <option value="gallery-breakfast">Breakfast</option>
                <option value="gallery-lunch">Lunch</option>
                <option value="gallery-dinner">Dinner</option>
                <option value="gallery-dessert">Dessert</option>
            </select>
            <button id="add-image">Add Image(s)</button>
        </div>
        <!-- Display uploaded images with delete buttons -->
        <div id="gallerylist">
            <!-- Images will be displayed here -->
        </div>
    </section>
</main>
    
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Function to add image(s) to the gallery
        document.getElementById("add-image").addEventListener("click", function() {
            var category = document.getElementById("category-select").value;
            var fileInput = document.getElementById("image-upload");
            var files = fileInput.files;
                
            if (files.length > 0) {
                for (var i = 0; i < files.length; i++) {
                    var file = files[i];
                    if (file) {
                        var reader = new FileReader();
                        reader.onload = function(event) {
                            var imageUrl = event.target.result;
                            addImageToGallery(imageUrl, category);
                        };
                        reader.readAsDataURL(file);
                    }
                }
            }
        });
            
        // Function to add image to the gallery list
        function addImageToGallery(imageUrl, category) {
            var galleryList = document.getElementById("gallerylist");
                
            var galleryBox = document.createElement("div");
            galleryBox.classList.add("gallery-box");
                
            var galleryBoxWrapper = document.createElement("div");
            galleryBoxWrapper.classList.add("gallery-box-wrapper");
                
            var galleryImg = document.createElement("div");
            galleryImg.classList.add("gallery-img");
            galleryImg.style.backgroundImage = "url(" + imageUrl + ")";
                
            var categoryLabel = document.createElement("div");
            categoryLabel.classList.add("category-label");
            categoryLabel.textContent = category;
                
            var deleteButton = document.createElement("button");
            deleteButton.textContent = "Delete";
            deleteButton.classList.add("delete-btn");
            deleteButton.addEventListener("click", function() {
                // Remove the image from the gallery when the delete button is clicked
                galleryList.removeChild(galleryBox);
            });
                
            galleryBoxWrapper.appendChild(galleryImg);
            galleryBox.appendChild(galleryBoxWrapper);
            galleryBox.appendChild(categoryLabel);
            galleryBox.appendChild(deleteButton);
                
            galleryList.appendChild(galleryBox);
        }
    });
</script>

</body>

</html>
