<?php
include("components/session.php");
include("components/connect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashbord.css">
    <link rel="stylesheet" href="assets/css/foodecart.css">
</head>
<body>
   <?php
   include("components/admin_header.php");
   ?>
   <center style="margin-left: 200px";>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <img src="assets/images/post-img2.jpg" class="card-img-top" alt="Image">
                <div class="card-body">
                    <h5 class="card-title">Why Foodecart</h5>
                    <p class="card-text">Admin can add information to motivate the people to choose Foodecart.</p>
                    <a href="whyFoodecartsection.php" class="btn btn-primary">Learn More</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="tab-content-img-box wow fadeIn">
                    <div class="tab-content-img" style="background-image: url('assets/images/items-img.jpg');">
                    </div>
                    <div class="tab-content-img-off">
                        <p>50% Off</p>
                    </div>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Offers</h5>
                    <p class="card-text">Check out the latest offers and promotions available on Foodecart. Create enticing deals to attract more customers and boost sales for your restaurant partners.</p>
                    <a href="offers.php" class="btn btn-primary">View Offers</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-4">
                <img src="assets/images/items-img5.jpg" class="card-img-top" alt="Image">
                <div class="card-body">
                    <h5 class="card-title">Orders</h5>
                    <p class="card-text">View and manage incoming orders from customers. Keep track of order statuses, process cancellations or refunds, and ensure timely delivery for a seamless customer experience.</p>
                    <a href="orderlist.php" class="btn btn-primary">View Orders</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <img src="assets/images/insta-img2.jpg" class="card-img-top" alt="Image">
                <div class="card-body">
                    <h5 class="card-title">Gallery</h5>
                    <p class="card-text">Showcase mouthwatering images of delicious dishes from our partner restaurants. Curate an attractive gallery to entice customers and encourage them to explore menus and place orders.</p>
                    <a href="gallary.php" class="btn btn-primary">View Gallery</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-4">
                <img src="assets/images/chef-img1.jpg" class="card-img-top" alt="Image">
                <div class="card-body">
                    <h5 class="card-title">Our Chefs</h5>
                    <p class="card-text">Highlight the talented chefs behind the exquisite cuisines available on Foodecart. Introduce their expertise, specialties, and culinary backgrounds to build trust and credibility among customers.</p>
                    <a href="ourchefs.php" class="btn btn-primary">Meet Our Chefs</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-4">
                <img src="https://plus.unsplash.com/premium_photo-1682310144714-cb77b1e6d64a?q=80&w=1824&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" class="card-img-top" alt="Image">
                <div class="card-body">
                    <h5 class="card-title">What Our client Says</h5>
                    <p class="card-text">"As an admin, I redirect you to our clients' testimonials, where their words speak volumes about their satisfaction and trust in our services."</p>
                    <a href="reviews.php" class="btn btn-primary">Add testimonials</a>
                </div>
            </div>
        </div>
    </div>
    
    </div>
</div>
</center>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
