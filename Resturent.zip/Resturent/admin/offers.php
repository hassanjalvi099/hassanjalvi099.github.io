<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="assets/css/offers.css">
   
    <link rel="stylesheet" href="assets/css/foodecart.css">
    <style>
        /* Adjust the width of the main section */
        main {
            width: 83%; /* Set the width to 70% */
            margin-left: auto; /* Align to the right */
            margin-right: 0; /* Remove default margin */
            padding: 20px;
        }
    </style>
</head>
<body>
<?php
include("components/admin_header.php");
?>
<main>
    <section id="manage-menu">
        <h2>Manage Menu</h2>
        <div class="menu-options">
            <button id="add-main-course" class="category-btn ">Add Main Course</button>
            <button id="add-soups-salads" class="category-btn ">Add Soups & Salads</button>
            <button id="add-thai-dishes" class="category-btn ">Add Thai Food Dishes</button>
            <button id="add-seafood-dishes" class="category-btn ">Add Sea Food Dishes</button>
            <button id="add-desserts" class="category-btn ">Add Desserts</button>
            <button id="add-drinks" class="category-btn ">Add Drinks</button>
        </div>
        <div id="add-form" style="display: none;">
            <form id="food-form" method="POST" action="">
                <label for="food-name">Food Name:</label>
                <input type="text" id="food-name" name="food-name" required><br><br>
                
                <label for="ingredients">Ingredients:</label><br>
                <textarea id="ingredients" name="ingredients" rows="4" cols="50" required></textarea><br><br>
                
                <label for="food-price">Price:</label>
                <input type="text" id="food-price" name="food-price" required><br><br>
                
                <button type="submit" name="add_product">Add Food</button>
            </form>
        </div>
        <!-- Display added foods with update and delete buttons -->
        <div id="food-list">
            <!-- Foods will be displayed here -->
        </div>
    </section>
</main>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Function to show or hide the form for adding food details
        function toggleAddForm(category) {
            var addForm = document.getElementById("add-form");
            addForm.style.display = addForm.style.display === "block" ? "none" : "block";
            console.log("Add " + category + " Form will be displayed here.");
        }
        
        // Function to display added foods
        function displayFoods() {
            // You can fetch the food items from the server and display them here
            var foodList = document.getElementById("food-list");
            var newFoodItem = document.createElement('div');
            newFoodItem.classList.add("food-item");
            newFoodItem.innerHTML = `
                <div class="food-details">
                    <h3 contenteditable="true">Food Name</h3>
                    <p contenteditable="true">Ingredients: Ingredient 1, Ingredient 2, Ingredient 3</p>
                    <p contenteditable="true">Price: $10.00</p>
                </div>
                <div class="food-actions">
                    <button class="update-btn">Update</button>
                    <button class="delete-btn">Delete</button>
                </div>
            `;
            foodList.appendChild(newFoodItem);

            // Add event listeners to update and delete buttons
            var updateButton = newFoodItem.querySelector('.update-btn');
            var deleteButton = newFoodItem.querySelector('.delete-btn');
            updateButton.addEventListener('click', function() {
                updateFoodItem(newFoodItem);
            });
            deleteButton.addEventListener('click', function() {
                deleteFoodItem(newFoodItem);
            });
        }

        // Function to update food item
        function updateFoodItem(foodItem) {
            var foodName = foodItem.querySelector('h3').innerText;
            var ingredients = foodItem.querySelectorAll('p')[0].innerText.replace('Ingredients: ', '');
            var price = foodItem.querySelectorAll('p')[1].innerText.replace('Price: ', '');

            // You can add your logic here to update the food item
            var updatedFoodName = foodItem.querySelector('h3[contenteditable="true"]').innerText;
            var updatedIngredients = foodItem.querySelectorAll('p')[0].innerText.replace('Ingredients: ', '');
            var updatedPrice = foodItem.querySelectorAll('p')[1].innerText.replace('Price: ', '');

            console.log("Updating food:", foodName, "to", updatedFoodName);
            console.log("Updating ingredients:", ingredients, "to", updatedIngredients);
            console.log("Updating price:", price, "to", updatedPrice);
        }

        // Function to delete food item
        function deleteFoodItem(foodItem) {
            // Add your logic to delete the food item
            foodItem.remove();
        }
        
        // Add event listener to the form submission for adding food
        document.getElementById("food-form").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission
            
            // After successful addition, display the updated list of foods
            displayFoods();
            
            // Hide the form after submission
            var addForm = document.getElementById("add-form");
            addForm.style.display = "none";
        });
        
        // Add event listeners to the buttons to show/hide the form
        document.getElementById("add-main-course").addEventListener("click", function() {
            toggleAddForm("Main Course");
        });
    
        document.getElementById("add-soups-salads").addEventListener("click", function() {
            toggleAddForm("Soups & Salads");
        });
    
        document.getElementById("add-thai-dishes").addEventListener("click", function() {
            toggleAddForm("Thai Food Dishes");
        });
    
        document.getElementById("add-seafood-dishes").addEventListener("click", function() {
            toggleAddForm("Sea Food Dishes");
        });
    
        document.getElementById("add-desserts").addEventListener("click", function() {
            toggleAddForm("Desserts");
        });
    
        document.getElementById("add-drinks").addEventListener("click", function() {
            toggleAddForm("Drinks");
        });
        
        // Display the initial list of foods
        displayFoods();
    });
</script>

</body>
</html>
