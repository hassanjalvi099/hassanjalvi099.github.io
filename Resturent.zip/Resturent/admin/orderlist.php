<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Placed Orders</title>

   <!-- Font Awesome CDN link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link  -->
   <link rel="stylesheet" href="assets/css/orders.css">
   <link rel="stylesheet" href="assets/css/foodecart.css">

</head>
<body>
<?php
include("components/admin_header.php");
?>
<!-- Admin header (assuming it's in the admin_header.php file) -->


<!-- Placed orders section starts  -->
<section class="placed-orders">

   <h1 class="heading">Placed Orders</h1>

   <div class="box-container">

      <!-- Dynamic content for placed orders -->

      <!-- Example order box -->
      <div class="box">
         <p>Date<span>2024-03-22</span></p>
         <p>Time:<span>9:35-10:35</span></p>
         <p>No.of guests:<span>5</span></p>
         <p>Name:<span>Hassan Jalvi</span></p>
      
         <form action="" method="POST">
            <input type="hidden" name="order_id" value="1">
            <select name="payment_status" class="drop-down">
               <option value="" selected disabled>Pending</option>
               <option value="pending">Pending</option>
               <option value="completed">Completed</option>
            </select>
            <div class="flex-btn">
               <input type="submit" value="Update" class="btn" name="update_payment">
               <a href="placed_orders.php?delete=1" class="delete-btn" onclick="return confirm('Delete this order?');">Delete</a>
            </div>
         </form>
      </div>
      
      <!-- Repeat the above box structure for other orders -->

      <!-- If there are no orders placed -->
      <!-- <p class="empty">No orders placed yet!</p> -->

   </div>

</section>
<!-- Placed orders section ends -->

<!-- Custom JavaScript file link  -->
<script src="../js/admin_script.js"></script>

</body>

</html>
