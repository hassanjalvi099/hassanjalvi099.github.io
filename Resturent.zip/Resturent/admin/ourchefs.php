<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/chefs.css">
    <link rel="stylesheet" href="assets/css/foodecart.css">
</head>
<body>
<?php
include("components/admin_header.php");
?>
    <section class="admin-panel" style="margin-top: 20px;">
        <h2>Manage Chefs</h2>
        <form class="admin-form" action="#" method="post">
            <label for="chef-name1">Chef Name:</label>
            <input type="text" id="chef-name1" name="chef-name1" placeholder="Enter Chef Name">
            
            <label for="chef-position1">Chef Position:</label>
            <input type="text" id="chef-position1" name="chef-position1" placeholder="Enter Chef Position">
            
            <label for="chef-image1">Chef Image:</label>
            <input type="file" id="chef-image1" name="chef-image1">
            
            <label for="chef-instagram1">Instagram:</label>
            <input type="text" id="chef-instagram1" name="chef-instagram1" placeholder="Enter Instagram URL">
            
            <label for="chef-facebook1">Facebook:</label>
            <input type="text" id="chef-facebook1" name="chef-facebook1" placeholder="Enter Facebook URL">
            
            <label for="chef-twitter1">Twitter:</label>
            <input type="text" id="chef-twitter1" name="chef-twitter1" placeholder="Enter Twitter URL">
            
            <button type="submit">Submit</button>
        </form>
    </section>    
</body>

</html>
