<?php
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include("components/connect.php");
    $username = mysqli_real_escape_string($conn, $_POST['name']);
    $password =  mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);
    
    // Get the maximum ID from the user table
    $maxIdQuery = "SELECT MAX(id) FROM user";
    $maxIdResult = mysqli_query($conn, $maxIdQuery);
    $maxIdRow = mysqli_fetch_array($maxIdResult);
    $maxId = $maxIdRow[0];
    $userId = $maxId + 1;

    // Check whether this username exists
    $existSql = "SELECT * FROM `user` WHERE username = '$username'";
    $result = mysqli_query($conn, $existSql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows > 0){
        $showError = "Username Already Exists";
    }
    else{
        if(($password == $cpassword)){
            $sql = "INSERT INTO `user` ( `id`, `username`, `password`, `dt`) VALUES ('$userId', '$username', '$password', current_timestamp())";
            $result = mysqli_query($conn, $sql);
            if ($result){
                $showAlert = true;
            }
        }
        else{
            $showError = "Passwords do not match";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/login.css">
    <link rel="stylesheet" href="assets/css/extras.css">
</head>
<body>
<style>
        body {
            background-image: url('assets/images/bg.jpg');
            background-size: cover;
        }
 </style>
    <div class="py-5 mt-10">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <?php
                    if($showAlert){
                        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Success!</strong> Your account is now created and you can login
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>';
                    }
                    if($showError){
                        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>Error!</strong> '. $showError.'
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>';
                    }
                    ?>
                    <div class="card shadow">
                        <div class="card-header">
                            <h5>Register</h5>
                        </div>
                        <div class="card-body">
                            <form method="post">
                                <div class="mb-3">
                                    <label for="fullName" class="form-label">Full Name</label>
                                    <input type="text" id="fullName" class="form-control" placeholder="Full Name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="typePasswordX" class="form-label">Password</label>
                                    <input type="password" id="typePasswordX" class="form-control" placeholder="Password" name="password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="confirmPassword" class="form-label">Confirm Password</label>
                                    <input type="password" id="confirmPassword" class="form-control" placeholder="Confirm Password" name="cpassword" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Register</button>
                            </form>
                            <div class="mt-3">
                                <p>Already have an account? <a href="adminlogin.php">Login</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="copy-right">
                        <p>&copy; 2024 <a href="#" title="FoodeCart">FoodeCart</a>. All rights reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>

