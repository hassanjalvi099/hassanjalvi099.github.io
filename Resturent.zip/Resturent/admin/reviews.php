<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/reviews.css"> 
    <link rel="stylesheet" href="assets/css/foodecart.css"><!-- Link to your CSS file -->
</head>
<body>
<?php
include("components/admin_header.php");
?>
    <section class="main-testimonial common-sec white-back">
        <!-- Testimonial content as provided -->
       
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonial-title">
                       
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonial-slider">
                        <!-- Testimonial boxes as provided -->
                    </div>
                </div>
            </div>
        </div>
    </section>    

    <!-- Admin Panel for Testimonials -->
    <section class="admin-panel" style="margin-top: -100px;">
        <h2 class="h2-title gray-after-effect">What Our Clients Say’s</h2>
        <form class="admin-form" action="#" method="post">
            <label for="client-name">Client Name:</label>
            <input type="text" id="client-name" name="client-name" placeholder="Enter Client Name">
            
            <label for="client-position">Client Position:</label>
            <input type="text" id="client-position" name="client-position" placeholder="Enter Client Position">
            
            <label for="client-image">Client Image:</label>
            <input type="file" id="client-image" name="client-image">
            
            <label for="client-review">Client Review:</label>
            <textarea id="client-review" name="client-review" placeholder="Enter Client Review"></textarea>
            
            <label for="client-rating">Client Rating:</label>
            <select id="client-rating" name="client-rating">
                <option value="1">1 Star</option>
                <option value="2">2 Stars</option>
                <option value="3">3 Stars</option>
                <option value="4">4 Stars</option>
                <option value="5">5 Stars</option>
            </select>
            
            <button type="submit">Add Testimonial</button>
        </form>
    </section>    
</body>

</html>
