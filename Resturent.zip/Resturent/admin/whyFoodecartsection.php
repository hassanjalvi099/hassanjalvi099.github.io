<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Why Foodecart Section</title>
    
    <link rel="stylesheet" href="assets/css/foodecart.css">
    
</head>
<body>
<?php
include("components/admin_header.php");
?>
    <!-- Form for Updating Why Foodecart Section -->
    
    <form id="why-foodecart-form" class="admin-form" action="update_why_foodecart.php" method="POST">
        <section class="admin-panel">
            <h2>Why Foodecart</h2>
        <label for="chef-text">Professional Chef:</label>
        <textarea id="chef-text" name="chef-text"></textarea>
        <label for="chef-image">Chef Image:</label>
        <input type="file" id="chef-image" name="chef-image">
        
        <label for="catering-text">Catering Services:</label>
        <textarea id="catering-text" name="catering-text"></textarea>
        <label for="catering-image">Catering Image:</label>
        <input type="file" id="catering-image" name="catering-image">
        
        <label for="quality-text">Quality Food:</label>
        <textarea id="quality-text" name="quality-text"></textarea>
        <label for="quality-image">Quality Image:</label>
        <input type="file" id="quality-image" name="quality-image">
        
        <button type="submit" style="background-color: #ff4f00; color: #fff;">Save Changes</button>
    </section>
    </form>

    <!-- Admin Panel Footer -->
    
</body>

</html>
