<?php
include("libraries/Variables.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo(constant('Blog'))?></title>
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="FoodeCart, HTML5 Template" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!-- FavIcon Link -->
	<link rel="icon" href="assets/images/favicon.png" type="image/gif" sizes="16x16">

	<!-- Bootstrap CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

	<!-- Date Picker CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">

	<!-- Font Awesome Icon CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">

	<!-- Slick Slider CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" href="assets/css/slick-theme.css">

	<!-- Wow Animation CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css">

	<!-- Main Style CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>


<body>

	<!-- Loader Start -->
	<div class="loader-box">
		<div class="loader">
		  <span></span>
		  <span></span>
		  <span></span>
		</div>
	</div>
	<!-- Loader Start -->

	<!-- Header Start -->
	<?php
	include("components/header.php");
	?>
	<!-- Header End -->

	<!-- Banner Start -->
	<section class="inner-banner" id="main-banner" style="background-image: url('assets/images/blog-detail-banner-img.jpg');">
		<span class="inner-banner-shape" style="background-image: url('assets/images/banner-shape.png');"></span>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12">
					<div class="banner-content">
						<h1 class="h1-title">Blog Detail</h1>
						<div class="breadcrumbs-box">
							<a href="index.html">Home</a>
							<span><i class="fa fa-angle-right breadcrumbs-arrow" aria-hidden="true"></i></span>
							<a href="blog.html">Blog</a>
							<span><i class="fa fa-angle-right breadcrumbs-arrow" aria-hidden="true"></i> Blog Detail</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Banner End -->

	<!-- Page Blog Content Start -->
	<section class="common-sec main-blog-page">
		<div class="element-top">
			<img src="assets/images/element1.png" alt="Element Image">
		</div>
		<div class="element-bottom">
			<img src="assets/images/element2.png" alt="Element Image">
		</div>
		<div class="element-top element-top2">
			<img src="assets/images/element3.png" alt="Element Image">
		</div>
		<div class="element-bottom element-bottom2">
			<img src="assets/images/element4.png" alt="Element Image">
		</div>
		<div class="element-top element-top3">
			<img src="assets/images/element5.png" alt="Element Image">
		</div>
		<div class="element-bottom element-bottom3">
			<img src="assets/images/element8.png" alt="Element Image">
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<div class="blog-page-content blog-detail-content">
						<div class="page-blog-post">
							<div class="page-post-img-box">
								<div class="page-post-img" style="background-image: url('assets/images/post-img1.jpg');"></div>
							</div>
							<div class="page-post-content">
								<div class="post-meta">
									<div class="page-meta-box page-post-date">
										<p>March 7, 2018</p>
									</div>
									<div class="page-meta-box post-by">
										<p>By Jhone Doe</p>
									</div>
									
								</div>
								<h3 class="h3-title">Donec interdum enim eget mi mattis, luctus malesuada ante placerat.</h3>
								<div class="post-text">
									<p>Quisque non interdum urna, sed ullamcorper massa. Nunc nulla odio, euismod sit amet risus eget, porttitor tincidunt tortor. Morbi et dignissim magna, eget dapibus velit. Curabitur non scelerisque est. Nam interdum turpis vel tortor ultricies, eu fringilla nunc bibendum.</p>
								</div>
								<div class="post-comment-box">
									<p>Vestibulum nec nisl eget augue condimentum ultricies. Vestibulum euismod est finibus risus vehicula suscipit. Morbi augue tellus, mattis vitae mi id, ornare pharetra lorem. Nunc vehicula enim ut lacus porttitor, sit amet consequat magna consectetur.</p>
									<img src="assets/images/double-quote-2.png" alt="Double Quote">
								</div>
								<div class="post-text">
									<p>Integer volutpat risus quis purus ornare vehicula. Nullam diam dolor, congue non viverra at, suscipit ac lectus. Curabitur non est facilisis, congue urna vel, ultricies odio. Curabitur lacinia laoreet est ut blandit. Etiam consequat dui quis ornare facilisis. Vivamus molestie mauris a lectus scelerisque ullamcorper. Vestibulum vehicula accumsan mi ut mattis.</p>
									<p>Nullam at quam massa. Nullam ultricies tellus pellentesque, dignissim velit in, tristique ex. Aliquam quam eros, feugiat quis nulla ut, interdum sagittis urna.</p>
								</div>
								<div class="post-meta">
									<div class="page-meta-box post-social-icon">
										<a href="javascript:void(0)" class="post-social-box" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
										<a href="javascript:void(0)" class="post-social-box" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
										<a href="javascript:void(0)" class="post-social-box" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</div>
									<div class="page-meta-box page-post-view">
										<a href="javascript:void(0)" title="Views"><img src="assets/images/icon-eye.png" alt="Eye Icon"><span>143</span></a>
										<a href="javascript:void(0)" title="Comments"><img src="assets/images/icon-message.png" alt="Message Icon"><span>27</span></a>
									</div>
								</div>
							</div>
						</div>
						<div class="related-post">
							<div class="row">
								<div class="col-md-6">
									<div class="blog-post">
										<div class="post-img-box">
											<div class="post-img" style="background-image: url('assets/images/post-img1.jpg');"></div>
										</div>
										<div class="post-content">
											<span class="post-date">March 7, 2018</span>
											<h5 class="post-title">Aenean magna, a lobortis mauris vehicula sed.</h5>
											<div class="post-description">
												<p>Donec condimentum tristique porta. Varius neque risus, a congue augue viverra id publishing software.</p>
											</div>
											<a href="blog.html" title="Read More">Read More <span><img src="assets/images/arrow-right.png" alt="Arrow" /></span></a>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="blog-post">
										<div class="post-img-box">
											<div class="post-img" style="background-image: url('assets/images/post-img2.jpg');"></div>
										</div>
										<div class="post-content">
											<span class="post-date">March 7, 2018</span>
											<h5 class="post-title">Vehicula magna, a lobortis mauris vehicula sed.</h5>
											<div class="post-description">
												<p>Donec condimentum tristique porta. Varius neque risus, a congue augue viverra id publishing software.</p>
											</div>
											<a href="blog.html" title="Read More">Read More <span><img src="assets/images/arrow-right.png" alt="Arrow" /></span></a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="details-post-comment">
							<h2 class="page-post-title">Comments</h2>
							<div class="detail-comment-box odd">
								<div class="detail-comment-img img-hover" style="background-image:url('assets/images/detail-comment-img1.jpg')"></div>
								<div class="detail-comment-text">
									<h5 class="detail-comment-title">Celesto Anderson</h5>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<a href="javascript:void(0)" title="Reply"><i class="fa fa-reply" aria-hidden="true"></i>Reply</a>
								</div>
							</div>
							<div class="detail-comment-box even">
								<div class="detail-comment-img img-hover" style="background-image:url('assets/images/detail-comment-img2.jpg')"></div>
								<div class="detail-comment-text">
									<h5 class="detail-comment-title">Jake Johnson</h5>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<a href="javascript:void(0)" title="Reply"><i class="fa fa-reply" aria-hidden="true"></i>Reply</a>
								</div>
							</div>
							<div class="detail-comment-box odd">
								<div class="detail-comment-img img-hover" style="background-image:url('assets/images/detail-comment-img3.jpg')"></div>
								<div class="detail-comment-text">
									<h5 class="detail-comment-title">John Doe</h5>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<a href="javascript:void(0)" title="Reply"><i class="fa fa-reply" aria-hidden="true"></i>Reply</a>
								</div>
							</div>
						</div>
						<div class="leave-review">
							<h2 class="page-post-title">Leave Reviews</h2>
							<form class="leave-review-form">
								<div class="row">
									<div class="col-lg-6">
										<div class="form-box">
											<input type="text" class="form-input2" name="fullname" placeholder="Full Name" required="">
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-box">
											<input type="email" class="form-input2" name="email" placeholder="Email Address" required="">
										</div>
									</div>
									<div class="col-lg-12">
										<div class="form-box">
											<textarea class="form-input2" placeholder="Message"></textarea>
										</div>
									</div>
									<div class="col-lg-12">
										<div class="form-box">
											<button type="submit" class="sec-btn"><span>Submit</span></button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="blog-sidebar">
						<div class="search-from">
							<h5 class="page-post-title">Search Now</h5>
							<form>
								<div class="form-box">
									<input type="text" name="search" placeholder="Search..." required class="form-input">
									<button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
								</div>
							</form>
						</div>
						<div class="common-sidebar-box recent-post">
							<h5 class="page-post-title">Recent Post</h5>
							<div class="recent-post-box">
								<div class="recent-post-img-box">
									<div class="recent-post-img" style="background-image:url('assets/images/recent-post-img1.jpg')"></div>
								</div>
								<div class="recent-post-text">
									<h6><a href="javascript:void(0)">Etiam molestie rhoncus eleifend</a></h6>
									<p>March 7, 2018</p>
								</div>
							</div>
							<div class="recent-post-box">
								<div class="recent-post-img-box">
									<div class="recent-post-img" style="background-image:url('assets/images/recent-post-img2.jpg')"></div>
								</div>
								<div class="recent-post-text">
									<h6><a href="javascript:void(0)">Etiam molestie rhoncus eleifend</a></h6>
									<p>March 7, 2018</p>
								</div>
							</div>
							<div class="recent-post-box">
								<div class="recent-post-img-box">
									<div class="recent-post-img" style="background-image:url('assets/images/recent-post-img3.jpg')"></div>
								</div>
								<div class="recent-post-text">
									<h6><a href="javascript:void(0)">Etiam molestie rhoncus eleifend</a></h6>
									<p>March 7, 2018</p>
								</div>
							</div>
							<div class="recent-post-box">
								<div class="recent-post-img-box">
									<div class="recent-post-img" style="background-image:url('assets/images/recent-post-img4.jpg')"></div>
								</div>
								<div class="recent-post-text">
									<h6><a href="javascript:void(0)">Etiam molestie rhoncus eleifend</a></h6>
									<p>March 7, 2018</p>
								</div>
							</div>
						</div>
						<div class="common-sidebar-box categories">
							<h5 class="page-post-title">Categories</h5>
							<ul>
								<li><a href="javascript:void(0)"><span class="categories-text">Seafood</span> <span>12</span></a></li>
								<li><a href="javascript:void(0)"><span class="categories-text">Receipts</span> <span>15</span></a></li>
								<li><a href="javascript:void(0)"><span class="categories-text">Dishes</span> <span>20</span></a></li>
								<li><a href="javascript:void(0)"><span class="categories-text">Travel</span> <span>8</span></a></li>
								<li><a href="javascript:void(0)"><span class="categories-text">Photos</span> <span>10</span></a></li>
							</ul>
						</div>
						<div class="common-sidebar-box top-chef">
							<h5 class="page-post-title">Top Chef</h5>
							<div class="top-chef-text">
								<div class="top-chef-img" style="background-image:url('assets/images/chef-img5.jpg')"></div>
								<h6>Joella Smith</h6>
								<p>Curabitur in massa dapibus, varius risus et, accumsan orci. Nam vehicula lobortis ex, vel fringilla dolor rutrum in. Sed ac ornare augue nam pretium, enim vel facilisis ullamcorper, diam urna luctus nisi, sit amet.</p>
								<span class="top-chef-signature">
									<img src="assets/images/top-chef-signature.png" title="Top Chef Signature">
								</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Page Blog Content End -->

	<!-- Footer Start -->
	<?php
	include("components/footer.php");
	?>
	<!-- Footer End -->

	<!-- Scroll To Top Start -->
	<a href="#main-banner" class="scroll-top" id="scroll-top"><span><i class="fa fa-angle-double-up" aria-hidden="true"></i></span></a>
	<!-- Scroll To Top End -->


	<!-- Jquery JS Link -->
	<script src="assets/js/jquery.min.js"></script>

	<!-- Bootstrap JS Link -->
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Date Picker JS Link -->
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/bootstrap-datetimepicker.min.js"></script>

	<!-- Mixitup JS - For Gallery Page Tabbing Link -->
	<script src="assets/js/jquery.mixitup.min.js"></script>

	<!-- Slick Slider JS Link -->
	<script src="assets/js/slick.min.js"></script>

	<!-- Wow Animation JS Link -->
	<script src="assets/js/wow.min.js"></script>	

	<!-- Custom JS Link -->
	<script src="assets/js/custom.js"></script>

</body>

<!-- Mirrored from shivaaythemes.in/foodecart-demo/Multiple_Pages/Homepage_1/blog-detail.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2024 17:18:37 GMT -->
</html>