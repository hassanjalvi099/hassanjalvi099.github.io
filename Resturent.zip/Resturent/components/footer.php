
<?php
include("connect.php");

if(isset($_POST['submit'])) {
    $Date = mysqli_real_escape_string($conn, $_POST['date']);
    $Time = mysqli_real_escape_string($conn, $_POST['time']);
    $NumberOfGuests = mysqli_real_escape_string($conn, $_POST['guest']);
    $YourName = mysqli_real_escape_string($conn, $_POST['name']);
    $YourEmail = mysqli_real_escape_string($conn, $_POST['email']);

    $TokenKey = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!*()$";
    $TokenKey = str_shuffle($TokenKey);
    $TokenKey = substr($TokenKey, 0, 32);

    $MySqlCommand = "SELECT MAX(id) FROM tablebook";
    
    $Result = mysqli_query($conn, $MySqlCommand);
    $MaxID = mysqli_fetch_array($Result);
    $UserID = $MaxID[0];
    $UserID = $UserID + 1;

    $TodayDate = date("Ymd");
    $Reference =  $TodayDate . "_" . str_pad($UserID, 8, "0", STR_PAD_LEFT);
    $Status = 0;
    $IP = $_SERVER['REMOTE_ADDR'];

    $Query = "INSERT INTO tablebook (id, reference, date, time, number_of_guests, your_name, your_email, status, ipaddress, token) ".
    "VALUES($UserID, '$Reference', '$Date', '$Time', '$NumberOfGuests', '$YourName', '$YourEmail', $Status, '$IP', '$TokenKey')";
    $Result = mysqli_query($conn, $Query);

    if ($Result) {
        ?>
        <script>
            alert('Thanks for Booking. We\'ll respond to you soon.');
            window.location.href='index.php?success';
        </script>
        <?php
    } else {
        ?>
        <script>
            alert('Exception found. Please contact us using our email.');
            window.location.href='index.php?error';
        </script>
        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	
</body>
</html>
<footer class="site-footer" id="contact" style="background-image: url('assets/images/footer-back.jpg');">
		<div class="container">
			<div class="row">
				<div class="col-xl-6 col-lg-8 col-md-12">
					<div class="footer-contact">
						<h2 class="h2-title">Book Your Table</h2>
						<div class="contact-form">
							<form  method="post">
								<div class="row">
									<div class="col-md-4">
										<div class="form-box">
											<input type="text" name="date" placeholder="Date" class="form-input" required id="datepicker">
											<span class="input-icon"><img src="assets/images/icon-calendar.png" alt="Input Icon" /></span>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-box">
											<input type="text" name="time" placeholder="Time" class="form-input" required id="timepicker">
											<span class="input-icon"><img src="assets/images/icon-time.png" alt="Input Icon" /></span>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-box">
											<input type="text" name="guest" placeholder="No. of Guest" class="form-input" required>
											<span class="input-icon"><img src="assets/images/icon-guest.png" alt="Input Icon" /></span>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-box">
											<input type="text" name="name" placeholder="Your Name" class="form-input" required>
											<span class="input-icon"><img src="assets/images/icon-user.png" alt="Input Icon" /></span>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-box">
											<input type="email" name="email" placeholder="Your Email" class="form-input">
											<span class="input-icon"><img src="assets/images/icon-mail.png" alt="Input Icon" /></span>
										</div>
									</div>
									<div class="col-md-12">
										<div class="submit-btn">
										<button type="submit" name="submit" class="btn btn-warning">Submit Now</button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-info">
			<div class="footer-info-img" style="background-image: url('assets/images/footer-back.jpg');"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-2 col-12 pr-lg-0">
						<div class="footer-logo">
							<p  title="FoodeCart"><img src="assets/images/logo.png" alt="Logo" /></p>
						</div>
						<div class="site-social-icon">
							<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
							<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
							<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						</div>
					</div>
					<div class="col-lg-7 col-12">
						<div class="footer-content">
							<div class="footer-menu">
								<ul>
									<li><a href="about-us.php">About Us</a></li>
									<li><a href="offer.php">Offer</a></li>
									<li><a href="menu.php">Menu</a></li>
									<li><a href="gallery.php">Gallery</a></li>
									<li><a href="team.php">Team</a></li>
									<li><a href="contact.php">Contact Us</a></li>
								</ul>
							</div>
							<p>"Welcome to FoodeCart, your one-stop destination for culinary delights! Explore our diverse menu featuring a fusion of flavors from around the globe. From hearty classics to innovative creations, we cater to every taste bud. Join us on a gastronomic adventure and elevate your dining experience with FoodeCart."</p>
						</div>
					</div>
					<div class="col-lg-3 col-12">
						<div class="subscribe-form">
							<h4>Subscribe Now!</h4>
							<form>
								<div class="form-box">
									<input type="email" name="subscribe_email" placeholder="Your Email" class="form-input" required>
									<button type="submit" id="send"><i class="fa fa-send" aria-hidden="true"></i></button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="copy-right">
								<p>Copyright &copy; 2020 <a href="index.php" title="FoodeCart">FoodeCart</a>. All rights reserved</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>