<header class="site-header">
		<div class="container">
			<div class="row">
				<div class="col-8 col-md-3">
					<!-- Logo Start -->
					<div class="site-logo">
						<a href="index.html" title="FoodeCart">
							<img src="assets/images/logo.png" alt="Logo" class="non-sticky" />
							<img src="assets/images/logo-black.png" alt="Logo" class="for-sticky" />
						</a>
					</div>
					<!-- Logo End -->
				</div>
				<div class="col-4 col-md-9">
					<!-- Menu Start -->
					<div class="header-menu">
						<!-- Navigation Menu Start -->
						<nav class="main-navigation">
							<button class="toggle-button">
								<span></span>
								<span></span>
								<span></span>
							</button>
							<ul class="menu">
								<li class="menu-item active"><a href="index.php">Home</a></li>
								<li class="menu-item"><a href="about-us.php">About Us</a></li>
								<li class="menu-item"><a href="offer.php">Offer</a></li>
								<li class="menu-item"><a href="menu.php">Menu</a></li>
								<li class="menu-item"><a href="gallery.php">Gallery</a></li>
								<li class="menu-item"><a href="team.php">Team</a></li>
								<li class="menu-item"><a href="contact.php">Contact Us</a></li>
								<li class="menu-item"><a href="contact.php">Login</a></li>
					
							</ul>
							<div class="mobile-social-icon">
								<div class="site-social-icon">
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
								</div>
							</div>
						</nav>
						<!-- Navigation Menu End -->
						<div class="black-shadow"></div>
					</div>
					<!-- Menu End -->
				</div>
			</div>
		</div>
	</header>