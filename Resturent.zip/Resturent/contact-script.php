<?php
include("components/connect.php");
if(isset($_POST['submit'])) {
    $FirstName = mysqli_real_escape_string($conn, $_POST['first_name']);
    $LastName = mysqli_real_escape_string($conn, $_POST['last_name']);
    $Email = mysqli_real_escape_string($conn, $_POST['email']);
    $PhoneNumber = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $Message = mysqli_real_escape_string($conn, $_POST['message']);
  
    $TokenKey = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!*()$";
    $TokenKey = str_shuffle($TokenKey);
    $TokenKey = substr($TokenKey, 0, 32);

    $MySqlCommand = "SELECT MAX(id) FROM contactus";
    // echo $MySqlCommand; 
    // die;
    $Result = mysqli_query($conn, $MySqlCommand);
    $MaxID = mysqli_fetch_array($Result);
    $UserID = $MaxID[0];
    $UserID = $UsreID + 1;

    $TodayDate = date("Ymd");
    $Reference =  $TodayDate . "_" . str_pad($UserID, 8, "0", STR_PAD_LEFT);
    $Status = 0;
    $IP = $_SERVER['REMOTE_ADDR'];
  
    $Query = "INSERT INTO contactus (id, reference, first_name, last_name, email, phone_number, message, status, ipaddress, token) ".
    "VALUES($UserID, '$Reference', '$FirstName', '$LastName', '$Email', '$PhoneNumber', '$Message', $Status, '$IP', '$TokenKey')";
    //  echo $Query;
    // die;
    $Result = mysqli_query($conn, $Query);
    // echo $Result;
    // die;
    if ($Result) {
        ?>
        <script>
            alert('Thanks for Contacting. We\'ll respond to you soon.');
            window.location.href='contact.php?success';
        </script>
        <?php
    } else {
        ?>
        <script>
            alert('Exception found. Please contact us using our email.');
            window.location.href='contact.php?error';
        </script>
        <?php
    }
}
?>
