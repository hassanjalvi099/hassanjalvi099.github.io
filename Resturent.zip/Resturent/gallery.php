<?php
include("libraries/Variables.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo(constant('Gallery'))?></title>
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="FoodeCart, HTML5 Template" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!-- FavIcon Link -->
	<link rel="icon" href="assets/images/favicon.png" type="image/gif" sizes="16x16">

	<!-- Bootstrap CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

	<!-- Date Picker CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">

	<!-- Font Awesome Icon CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">

	<!-- Slick Slider CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" href="assets/css/slick-theme.css">

	<!-- Wow Animation CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css">

	<!-- Main Style CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>


<body>

	<!-- Loader Start -->
	<div class="loader-box">
		<div class="loader">
		  <span></span>
		  <span></span>
		  <span></span>
		</div>
	</div>
	<!-- Loader Start -->

	<!-- Header Start -->
	<?php
	include("components/header.php");
	?>
	<!-- Header End -->

	<!-- Banner Start -->
	<section class="inner-banner" id="main-banner" style="background-image: url('assets/images/gallery-banner-img.jpg');">
		<span class="inner-banner-shape" style="background-image: url('assets/images/banner-shape.png');"></span>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12">
					<div class="banner-content">
						<h1 class="h1-title">Our Gallery</h1>
						<div class="breadcrumbs-box">
							<a href="index.html">Home</a>
							<span><i class="fa fa-angle-right breadcrumbs-arrow" aria-hidden="true"></i> Gallery</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Banner End -->

	<div class="main-gallery common-sec">
		<div class="element-top">
			<img src="assets/images/element1.png" alt="Element Image">
		</div>
		<div class="element-bottom">
			<img src="assets/images/element2.png" alt="Element Image">
		</div>
        <div class="container">
        	<div class="row">
        		<div class="col-12">
        			<ul class="clearfix" id="filters">
		                <li class="filter active" data-filter=".all, .gallery-breakfast, .gallery-lunch, .gallery-dinner, .gallery-dessert">All</li>
		                <li class="filter" data-filter=".gallery-breakfast">Breakfast</li>
		                <li class="filter" data-filter=".gallery-lunch">Lunch</li>
		                <li class="filter" data-filter=".gallery-dinner">Dinner</li>
		                <li class="filter" data-filter=".gallery-dessert">Dessert</li>
		            </ul>
		            <div class="gallerylist" id="gallerylist">
		                <div class="gallery-box gallery-breakfast" data-cat=".gallery-breakfast">
		                    <div class="gallery-box-wrapper">
		                        <div class="gallery-img" style="background-image: url(assets/images/insta-img1.jpg)"></div>
		                    </div>
		                </div>
		                <div class="gallery-box gallery-lunch" data-cat=".gallery-lunch">
		                    <div class="gallery-box-wrapper">
		                        <div class="gallery-img" style="background-image: url(assets/images/insta-img2.jpg)"></div>
		                    </div>
		                </div>
		                <div class="gallery-box gallery-dinner" data-cat=".gallery-dinner">
		                    <div class="gallery-box-wrapper">
		                        <div class="gallery-img" style="background-image: url(assets/images/insta-img3.jpg)"></div>
		                    </div>
		                </div>
		                <div class="gallery-box gallery-dessert" data-cat=".gallery-dessert">
		                    <div class="gallery-box-wrapper">
		                        <div class="gallery-img" style="background-image: url(assets/images/insta-img4.jpg)"></div>
		                    </div>
		                </div>
		                <div class="gallery-box gallery-breakfast" data-cat=".gallery-breakfast">
		                    <div class="gallery-box-wrapper">
		                        <div class="gallery-img" style="background-image: url(assets/images/insta-img5.jpg)"></div>
		                    </div>
		                </div>
		                <div class="gallery-box gallery-lunch" data-cat=".gallery-lunch">
		                    <div class="gallery-box-wrapper">
		                        <div class="gallery-img" style="background-image: url(assets/images/insta-img6.jpg)"></div>
		                    </div>
		                </div>
		            </div>
        		</div>
        	</div>
        </div>
    </div>

	<!-- Footer Start -->
	<?php
	include("components/footer.php");
	?>
	<!-- Footer End -->

	<!-- Scroll To Top Start -->
	<a href="#main-banner" class="scroll-top" id="scroll-top"><span><i class="fa fa-angle-double-up" aria-hidden="true"></i></span></a>
	<!-- Scroll To Top End -->


	<!-- Jquery JS Link -->
	<script src="assets/js/jquery.min.js"></script>

	<!-- Bootstrap JS Link -->
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Date Picker JS Link -->
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/bootstrap-datetimepicker.min.js"></script>

	<!-- Mixitup JS - For Gallery Page Tabbing Link -->
	<script src="assets/js/jquery.mixitup.min.js"></script>

	<!-- Slick Slider JS Link -->
	<script src="assets/js/slick.min.js"></script>

	<!-- Wow Animation JS Link -->
	<script src="assets/js/wow.min.js"></script>	

	<!-- Custom JS Link -->
	<script src="assets/js/custom.js"></script>
	<script src="assets/js/custom-gallery.js"></script>

</body>

<!-- Mirrored from shivaaythemes.in/foodecart-demo/Multiple_Pages/Homepage_1/gallery.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2024 17:18:05 GMT -->
</html>