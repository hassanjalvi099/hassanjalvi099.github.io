<?php
include("libraries/Variables.php");
// include("libraries/session.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo(constant('Home'))?></title>
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="FoodeCart, HTML5 Template" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!-- FavIcon Link -->
	<link rel="icon" href="assets/images/favicon.png" type="image/gif" sizes="16x16">

	<!-- Bootstrap CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

	<!-- Date Picker CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">

	<!-- Font Awesome Icon CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">

	<!-- Slick Slider CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" href="assets/css/slick-theme.css">

	<!-- Wow Animation CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css">

	<!-- Main Style CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	
	
	
</head>


<body>

	<!-- Loader Start -->
	<div class="loader-box">
		<div class="loader">
		  <span></span>
		  <span></span>
		  <span></span>
		</div>
	</div>
	<!-- Loader Start -->

	<!-- Header Start -->
<?php
include("components/header.php");
?>
	<!-- Header End -->

	<!-- Banner Start -->
	<section class="main-banner" id="main-banner">
		<div class="banner-slider">
			<div class="banner-slide-box" style="background-image: url('assets/images/banner-img.jpg');"></div>
			<div class="banner-slide-box" style="background-image: url('assets/images/banner-img2.jpg');"></div>
			<div class="banner-slide-box" style="background-image: url('assets/images/banner-img3.jpg');"></div>
			<div class="banner-slide-box" style="background-image: url('assets/images/banner-img4.jpg');"></div>
		</div>
		<span class="banner-shape" style="background-image: url('assets/images/banner-shape.png');"></span>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-12 col-lg-11 col-xl-9">
					<div class="banner-content">
						<h1 class="h1-title wow flipInX">We Serve Delicious Food</h1>
						<p>"Indulge in our exquisite culinary delights at 'We Serve Delicious Food.' Savor every bite of our mouthwatering dishes crafted with passion and expertise. Join us for an unforgettable dining experience filled with flavor and satisfaction."</p>
						<a href="offer.php" title="See Full Menu" class="sec-btn-transparent wow fadeInUp"><span>See Full Menu</span></a>
					</div>
				</div>
			</div>
			<div class="site-social-media">
				<span>Follow Us</span>
				<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
			</div>
		</div>
		<div class="scroll-down">
			<a href="#about-us" title="Scroll To Down"><span></span><span></span></a>
		</div>
	</section>
	<!-- Banner End -->

	<!-- Welcome To FoodeCart Start -->
	<section class="common-sec main-welcome" id="about-us">
		<div class="element-top">
			<img src="assets/images/element1.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element2.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-6 col-md-8">
					<div class="welcome-img wow fadeIn">
						<img src="assets/images/welcome-img.png" alt="Welcome Image" />
					</div>
				</div>
				<div class="col-lg-6 col-md-12">
					<div class="welcome-content">
						<h2 class="h2-title">Welcome To Foodecart</h2>
						<p>"Welcome to Foodecart, where every craving meets its match. Dive into a world of culinary delights with our diverse menu. From savory classics to innovative creations, we cater to every palate. Join us and embark on a gastronomic journey like no other. Satisfaction guaranteed, one bite at a time."</p>
						
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Welcome To FoodeCart End -->

	<!-- Top Item’s We Have In Start -->
	<section class="main-top-items common-sec" id="offer">
		<div class="element-top">
			<img src="assets/images/element3.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element4.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="top-items-title">
						<h2 class="h2-title gray-after-effect">Top Item’s We Have In</h2>
					</div>
					<div class="top-items-tabbing">
						<div class="top-items-tab-list">
							<ul class="nav nav-tabs" id="myTab" role="tablist">
							  <li class="nav-item">
							    <a class="nav-link active" id="breakfast-tab" data-toggle="tab" href="#breakfast" role="tab" aria-controls="breakfast" aria-selected="true">
							    	<span>
							    		<span class="tab-icon">
							    			<img src="assets/images/breakfast.png" class="tab-icon-active" alt="Breakfast Icon" />
							    			<img src="assets/images/breakfast-white.png" class="tab-icon-hover" alt="Breakfast Icon" />
							    		</span>
							    		Breakfast
							    	</span>
							    </a>
							  </li>
							  <li class="nav-item">
							    <a class="nav-link" id="lunch-tab" data-toggle="tab" href="#lunch" role="tab" aria-controls="lunch" aria-selected="false">
							    	<span>
							    		<span class="tab-icon">
								    		<img src="assets/images/lunch.png" class="tab-icon-active" alt="Lunch Icon" />
								    		<img src="assets/images/lunch-white.png" class="tab-icon-hover" alt="Lunch Icon" />
							    		</span>
							    		Lunch
							    	</span>	
							    </a>
							  </li>
							  <li class="nav-item">
							    <a class="nav-link" id="dinner-tab" data-toggle="tab" href="#dinner" role="tab" aria-controls="dinner" aria-selected="false">
							    	<span>
							    		<span class="tab-icon">
							    			<img src="assets/images/dinner.png" class="tab-icon-active" alt="Dinner Icon" />
							    			<img src="assets/images/dinner-white.png" class="tab-icon-hover" alt="Dinner Icon" />
							    		</span>
							    		Dinner
							    	</span>
							    </a>
							  </li>
							  <li class="nav-item">
							    <a class="nav-link" id="dessert-tab" data-toggle="tab" href="#dessert" role="tab" aria-controls="dessert" aria-selected="false">
							    	<span>
							    		<span class="tab-icon">
								    		<img src="assets/images/dessert.png" alt="Dessert Icon" />
								    		<img src="assets/images/dessert-white.png" class="tab-icon-hover" alt="Dessert Icon" />
								    	</span>
							    		Dessert
							    	</span>
							    </a>
							  </li>
							</ul>
						</div>
						<div class="tab-content top-items-tab-content" id="myTabContent">
							<div class="tab-pane fade show active" id="breakfast" role="tabpanel" aria-labelledby="breakfast-tab">
								<div class="row align-items-center">
									<div class="col-lg-6 col-md-12 order-lg-1 order-2">
										<div class="tab-content-text">
											<h3 class="h3-title">Fried Egg & Pancake Topped With Bacon And Orange Juice</h3>
										     <p>Start your day right with our mouthwatering Fried Egg & Pancake topped with crispy bacon. Pair it perfectly with a refreshing glass of freshly squeezed orange juice. Indulge in the perfect balance of savory and sweet flavors, making breakfast an experience to savor every morning.</p>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 order-lg-2 order-1">
										<div class="tab-content-img-box wow fadeIn">
											<div class="tab-content-img" style="background-image: url('assets/images/items-img.jpg');">
											</div>
											<div class="tab-content-img-off">
												<p>50% Off</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="lunch" role="tabpanel" aria-labelledby="lunch-tab">
								<div class="row align-items-center">
									<div class="col-lg-6 col-md-12 order-lg-1 order-2">
										<div class="tab-content-text">
											<h3 class="h3-title">Traditional Shrimp Thai Dish</h3>
											<p>Transport your taste buds to Thailand with our authentic Traditional Shrimp Thai Dish. Succulent shrimp simmered in a fragrant blend of traditional Thai spices and herbs, creating a symphony of flavors that will tantalize your senses. Experience the true essence of Thai cuisine with every delicious bite.</p>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 order-lg-2 order-1">
										<div class="tab-content-img-box">
											<div class="tab-content-img" style="background-image: url('assets/images/items-img2.jpg');">
											</div>
											<div class="tab-content-img-off">
												<p>38% Off</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="dinner" role="tabpanel" aria-labelledby="dinner-tab">
								<div class="row align-items-center">
									<div class="col-lg-6 col-md-12 order-lg-1 order-2">
										<div class="tab-content-text">
											<h3 class="h3-title">Traditional Indonesian Dish</h3>
											<p>Embark on a culinary journey to Indonesia with our Traditional Indonesian Dish. Bursting with aromatic spices and rich flavors, this dish captures the essence of Indonesian cuisine. Indulge in tender meats or vibrant vegetables, perfectly complemented by fragrant rice and savory sauces. Experience the exotic taste of Indonesia today.</p>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 order-lg-2 order-1">
										<div class="tab-content-img-box">
											<div class="tab-content-img" style="background-image: url('assets/images/items-img3.jpg');">
											</div>
											<div class="tab-content-img-off">
												<p>55% Off</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="dessert" role="tabpanel" aria-labelledby="dessert-tab">
								<div class="row align-items-center">
									<div class="col-lg-6 col-md-12 order-lg-1 order-2">
										<div class="tab-content-text">
											<h3 class="h3-title">Cupcake, Cheesecake & Sweet Bread</h3>
											<p>Treat yourself to a delightful array of sweet delights with our Cupcake, Cheesecake & Sweet Bread selection. Indulge in the moist and fluffy cupcakes, decadent cheesecakes, and irresistible sweet bread. Perfect for any occasion or as a sweet pick-me-up, each bite is a heavenly delight you won't soon forget.</p>
										</div>
									</div>
									<div class="col-lg-6 col-md-12 order-lg-2 order-1">
										<div class="tab-content-img-box">
											<div class="tab-content-img" style="background-image: url('assets/images/items-img4.jpg');">
											</div>
											<div class="tab-content-img-off">
												<p>30% Off</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Top Item’s We Have In End -->

	<!-- Our Food Menu Start -->
	<section class="main-food common-sec" id="menu-food">
		<div class="element-top">
			<img src="assets/images/element5.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element6.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="food-title">
						<h2 class="h2-title">Our Food Menu</h2>
					</div>
				</div>
			</div>
			<div class="main-menu-list">
				<div class="row">
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Main Course</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Super-Delicious Zuppa Toscana</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Bacon Coil Baked Australian Beef</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Soups & Salads</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Salat Banana Flower</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Gourmet Mushroom Risotto</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Desserts</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Ice Cream Tarte Apple</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Apple</li>
										<li>Italian</li>
										<li>Milk</li>
										<li>Fruit</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Fruit ‘Mille Feuille’</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Apple</li>
										<li>Italian</li>
										<li>Milk</li>
										<li>Fruit</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Drinks</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Double Chocolate Shake</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Ice</li>
										<li>Italian</li>
										<li>Fruit</li>
										<li>Chocolate</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">All Fruit Milk Shake</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Ice</li>
										<li>Italian</li>
										<li>Fruit</li>
										<li>Chocolate</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Our Food Menu End -->

	<!-- Instagram Image Slider Start -->
	<div class="main-instagram common-sec" id="gallery">
		<div class="instagram-slider">
			<div class="instagram-slide-box">
				<div class="instagram-slide-img" style="background-image: url('assets/images/insta-img1.jpg');"></div>
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</div>
			<div class="instagram-slide-box">
				<div class="instagram-slide-img" style="background-image: url('assets/images/insta-img2.jpg');"></div>
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</div>
			<div class="instagram-slide-box">
				<div class="instagram-slide-img" style="background-image: url('assets/images/insta-img3.jpg');"></div>
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</div>
			<div class="instagram-slide-box">
				<div class="instagram-slide-img" style="background-image: url('assets/images/insta-img4.jpg');"></div>
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</div>
			<div class="instagram-slide-box">
				<div class="instagram-slide-img" style="background-image: url('assets/images/insta-img5.jpg');"></div>
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</div>
			<div class="instagram-slide-box">
				<div class="instagram-slide-img" style="background-image: url('assets/images/insta-img6.jpg');"></div>
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</div>
			<div class="instagram-slide-box">
				<div class="instagram-slide-img" style="background-image: url('assets/images/insta-img7.jpg');"></div>
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</div>
		</div>
	</div>
	<!-- Instagram Image Slider End -->

	<!-- Our Chefs Start -->
	<section class="main-chefs common-sec" id="team">
		<div class="element-top">
			<img src="assets/images/element7.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element8.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="chefs-title">
						<h2 class="h2-title">Our Chefs</h2>
					</div>
				</div>
			</div>
			<div class="chefs-info">
				<div class="row chefs-slider">
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img1.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Joella Smith</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img2.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Jordan Peter</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img3.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Zoe Drew</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img4.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">James Doe</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img5.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Mena Roni</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="chef-info-box">
							<div class="chef-img-box">
								<div class="chef-img" style="background-image: url('assets/images/chef-img6.jpg');"></div>
							</div>
							<div class="chef-detail">
								<div class="chef-name">
									<h3 class="h3-title">Ramzy Smith</h3>
									<p class="chef-position">Co - Chef</p>
								</div>
								<div class="chef-social-info">
									<a href="javascript:void(0)" title="Follow on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									<a href="javascript:void(0)" title="Follow on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Our Chefs End -->

	<!-- Testimonial - What Our Clients Say’s Start -->
	<section class="main-testimonial common-sec">
		<div class="element-top">
			<img src="assets/images/element9.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element10.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="testimonial-title">
						<h2 class="h2-title gray-after-effect">What Our Clients Say’s</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="testimonial-slider">
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img2.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img3.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
						<div class="testimonial-box" style="background-image: url('assets/images/testimonial-back.jpg');">
							<div class="client-review">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="client-comments">
								<p>Duis diam nunc, venenatis sit amet nibh vel, imperdiet blandit risus. Pellentesque pretium, tortor vel consequat consequat, nibh est pretium ante, quis fermentum augue tellus sit amet augue. Morbi nec maximus mauris.</p>
							</div>
							<div class="client-info">
								<div class="client-img" style="background-image: url('assets/images/client-img4.jpg');"></div>
								<h6 class="client-name">Jon Bondic</h6>
								<span class="clinet-position">Author</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Testimonial - What Our Clients Say’s End -->

	<!-- Our Blog Start -->
	
	<!-- Our Blog End -->

	<!-- Footer Start -->
	<?php
	require("components/footer.php");
	?>
	<!-- Footer End -->

	<!-- Scroll To Top Start -->
	<a href="#main-banner" class="scroll-top" id="scroll-top"><span><i class="fa fa-angle-double-up" aria-hidden="true"></i></span></a>
	<!-- Scroll To Top End -->


	<!-- Jquery JS Link -->
	<script src="assets/js/jquery.min.js"></script>

	<!-- Bootstrap JS Link -->
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Date Picker JS Link -->
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/bootstrap-datetimepicker.min.js"></script>

	<!-- Slick Slider JS Link -->
	<script src="assets/js/slick.min.js"></script>

	<!-- Wow Animation JS Link -->
	<script src="assets/js/wow.min.js"></script>	

	<!-- Custom JS Link -->
	<script src="assets/js/custom.js"></script>

</body>

<!-- Mirrored from shivaaythemes.in/foodecart-demo/Multiple_Pages/Homepage_1/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2024 17:16:54 GMT -->
</html>