<?php
include("libraries/Variables.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo(constant('Menue'))?></title>
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="FoodeCart, HTML5 Template" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!-- FavIcon Link -->
	<link rel="icon" href="assets/images/favicon.png" type="image/gif" sizes="16x16">

	<!-- Bootstrap CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

	<!-- Date Picker CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">

	<!-- Font Awesome Icon CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">

	<!-- Slick Slider CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" href="assets/css/slick-theme.css">

	<!-- Wow Animation CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css">

	<!-- Main Style CSS Link -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>


<body>

	<!-- Loader Start -->
	<div class="loader-box">
		<div class="loader">
		  <span></span>
		  <span></span>
		  <span></span>
		</div>
	</div>
	<!-- Loader Start -->

	<!-- Header Start -->
	<?php
	include("components/header.php");
	?>

	<!-- Header End -->

	<!-- Banner Start -->
	<section class="inner-banner" id="main-banner" style="background-image: url('assets/images/menu-banner-img.jpg');">
		<span class="inner-banner-shape" style="background-image: url('assets/images/banner-shape.png');"></span>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12">
					<div class="banner-content">
						<h1 class="h1-title">Our Menu</h1>
						<div class="breadcrumbs-box">
							<a href="index.html">Home</a>
							<span><i class="fa fa-angle-right breadcrumbs-arrow" aria-hidden="true"></i> Menu</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Banner End -->

	<!-- Our Food Menu Start -->
	<section class="main-food common-sec page-food" id="menu-food">
		<div class="element-top">
			<img src="assets/images/element1.png" alt="Element Image" />
		</div>
		<div class="element-top element-top2">
			<img src="assets/images/element5.png" alt="Element Image" />
		</div>
		<div class="element-bottom">
			<img src="assets/images/element4.png" alt="Element Image" />
		</div>
		<div class="container">
			<div class="main-menu-list">
				<div class="row">
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Main Course</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Super-Delicious Zuppa Toscana</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Bacon Coil Baked Australian Beef</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Super-Delicious Zuppa Toscana</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Bacon Coil Baked Australian Beef</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Soups & Salads</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Salat Banana Flower</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Gourmet Mushroom Risotto</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Salat Banana Flower</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Gourmet Mushroom Risotto</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Thai Food Dishes</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Super-Delicious Zuppa Toscana</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Bacon Coil Baked Australian Beef</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Super-Delicious Zuppa Toscana</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Bacon Coil Baked Australian Beef</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Sea Food Dishes</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Salat Banana Flower</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Gourmet Mushroom Risotto</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Salat Banana Flower</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Gourmet Mushroom Risotto</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Chicken</li>
										<li>Italian</li>
										<li>Sausage</li>
										<li>Spinach</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Desserts</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Ice Cream Tarte Apple</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Apple</li>
										<li>Italian</li>
										<li>Milk</li>
										<li>Fruit</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Fruit ‘Mille Feuille’</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Apple</li>
										<li>Italian</li>
										<li>Milk</li>
										<li>Fruit</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Ice Cream Tarte Apple</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Apple</li>
										<li>Italian</li>
										<li>Milk</li>
										<li>Fruit</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Fruit ‘Mille Feuille’</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Apple</li>
										<li>Italian</li>
										<li>Milk</li>
										<li>Fruit</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="food-menu-box">
							<h3 class="h3-title">Drinks</h3>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Double Chocolate Shake</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Ice</li>
										<li>Italian</li>
										<li>Fruit</li>
										<li>Chocolate</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">All Fruit Milk Shake</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Ice</li>
										<li>Italian</li>
										<li>Fruit</li>
										<li>Chocolate</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">Double Chocolate Shake</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Ice</li>
										<li>Italian</li>
										<li>Fruit</li>
										<li>Chocolate</li>
									</ul>
								</div>
							</div>
							<div class="food-list-box">
								<div class="food-list">
									<h5 class="food-name">All Fruit Milk Shake</h5>
									<p class="food-price">$40</p>
								</div>
								<div class="food-types">
									<ul>
										<li>Ice</li>
										<li>Italian</li>
										<li>Fruit</li>
										<li>Chocolate</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Our Food Menu End -->

	<!-- Footer Start -->
	<?php
	include("components/footer.php");
	?>
	<!-- Footer End -->

	<!-- Scroll To Top Start -->
	<a href="#main-banner" class="scroll-top" id="scroll-top"><span><i class="fa fa-angle-double-up" aria-hidden="true"></i></span></a>
	<!-- Scroll To Top End -->


	<!-- Jquery JS Link -->
	<script src="assets/js/jquery.min.js"></script>

	<!-- Bootstrap JS Link -->
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Date Picker JS Link -->
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/bootstrap-datetimepicker.min.js"></script>

	<!-- Slick Slider JS Link -->
	<script src="assets/js/slick.min.js"></script>

	<!-- Wow Animation JS Link -->
	<script src="assets/js/wow.min.js"></script>	

	<!-- Custom JS Link -->
	<script src="assets/js/custom.js"></script>

</body>

<!-- Mirrored from shivaaythemes.in/foodecart-demo/Multiple_Pages/Homepage_1/menu.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2024 17:18:04 GMT -->
</html>